from cryptarithm.cryptarithm import *
name = "cryptarithm"